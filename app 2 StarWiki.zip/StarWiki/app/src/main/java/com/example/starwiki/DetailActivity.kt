package com.example.starwiki

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.starwiki.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val char = intent.getParcelableExtra<SWCharacter>("EXTRA_CHAR") ?: return finish()
        binding.imgPortraitDetail.setImageResource(char.imageRes)
        binding.txtNameDetail.text = char.name
        binding.txtBirthYear.text = "Birth Year: ${char.birthYear}"
        binding.txtSpecies.text = "Species: ${char.species}"
        binding.txtAlignment.text = "Alignment: ${char.alignment}"
        binding.txtHomeworld.text = "Homeworld: ${char.homeworld}"
        binding.txtAffiliation.text = "Affiliation: ${char.affiliation}"
        binding.txtRank.text = "Rank: ${char.rank}"
        binding.txtHeight.text = "Height: ${char.height}"
        binding.txtWeapon.text = "Weapon: ${char.weapon}"
        binding.txtAppearances.text = "Notable: ${char.notableAppearances}"
        binding.txtActor.text = "Actor: ${char.actor}"
        binding.txtKeyFacts.text = char.keyFacts
        binding.btnBack.setOnClickListener { finish() }
    }
}
