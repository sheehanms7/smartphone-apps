package com.example.starwiki

import android.os.Parcelable
import androidx.annotation.DrawableRes
import kotlinx.parcelize.Parcelize

@Parcelize
data class SWCharacter(
    val name: String,
    @DrawableRes val imageRes: Int,
    val birthYear: String,
    val species: String,
    val alignment: String,
    val homeworld: String,
    val affiliation: String,
    val rank: String,
    val height: String,
    val weapon: String,
    val notableAppearances: String,
    val actor: String,
    val keyFacts: String
) : Parcelable
