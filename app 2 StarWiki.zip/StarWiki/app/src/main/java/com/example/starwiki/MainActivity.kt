package com.example.starwiki

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.example.starwiki.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        AlertDialog.Builder(this)
            .setTitle("Welcome to StarWiki")
            .setMessage("Tap any character to view full Star Wars details.")
            .setPositiveButton("Got it") { dlg, _ -> dlg.dismiss() }
            .show()
        binding.rvCharacters.layoutManager = GridLayoutManager(this, 2)
        binding.rvCharacters.adapter = CharacterAdapter(getAllCharacters()) { char ->
            startActivity(
                Intent(this, DetailActivity::class.java)
                    .putExtra("EXTRA_CHAR", char)
            )
        }
    }

    private fun getAllCharacters(): List<SWCharacter> = listOf(
        SWCharacter("Luke Skywalker", R.drawable.luke, "19 BBY", "Human", "Light Side", "Tatooine", "Rebel Alliance", "General", "1.72 m", "Green Lightsaber", "IV, V, VI, VII, VIII", "Mark Hamill", "Key figure in the destruction of the Death Star."),
        SWCharacter("Darth Vader", R.drawable.darth, "41.9 BBY", "Human (cyborg)", "Dark Side", "Tatooine", "Galactic Empire", "Sith Lord", "2.03 m", "Red Lightsaber", "III, IV, V, VI", "James Earl Jones / David Prowse", "Once Jedi Anakin Skywalker."),
        SWCharacter("Leia Organa", R.drawable.leia, "19 BBY", "Human", "Light Side", "Alderaan", "Rebel Alliance", "General", "1.50 m", "Blaster", "IV, V, VI, VII, VIII", "Carrie Fisher", "Princess of Alderaan and leader."),
        SWCharacter("Han Solo", R.drawable.han, "29 BBY", "Human", "Light Side", "Corellia", "Rebel Alliance", "General", "1.8 m", "Blaster", "IV, V, VI, VII, VIII", "Harrison Ford", "Smuggler-turned-hero."),
        SWCharacter("Yoda", R.drawable.yoda, "896 BBY", "Yoda's species", "Light Side", "Unknown", "Jedi Order", "Grand Master", "0.66 m", "Green Lightsaber", "II, V, VIII", "Frank Oz", "Wise Jedi Master."),
        SWCharacter("Obi-Wan Kenobi", R.drawable.obiwan, "57 BBY", "Human", "Light Side", "Stewjon", "Jedi Order", "Jedi Master", "1.82 m", "Blue Lightsaber", "I, II, III, IV", "Ewan McGregor / Alec Guinness", "Mentored Anakin and Luke."),
        SWCharacter("Chewbacca", R.drawable.chewbacca, "200 BBY", "Wookiee", "Light Side", "Kashyyyk", "Rebel Alliance", "Co-pilot", "2.28 m", "Bowcaster", "III, IV, V, VI", "Peter Mayhew / Joonas Suotamo", "Loyal companion to Han Solo."),
        SWCharacter("R2-D2", R.drawable.r2, "33 BBY", "Droid", "Light Side", "Naboo", "Rebel Alliance", "Astromech Droid", "0.96 m", "Buzzers/Tools", "I, II, III, IV, V, VI", "Kenny Baker", "Resourceful astromech."),
        SWCharacter("C-3PO", R.drawable.c3po, "112 BBY", "Droid", "Light Side", "Tatooine", "Rebel Alliance", "Protocol Droid", "1.67 m", "Fluorescent sensors", "I, II, III, IV, V, VI", "Anthony Daniels", "Fluent in six million forms of communication."),
        SWCharacter("Emperor Palpatine", R.drawable.palpatine, "84 BBY", "Human", "Dark Side", "Naboo", "Galactic Empire", "Emperor", "1.7 m", "Red Lightsaber", "I, VI", "Ian McDiarmid", "Sith Master of Darth Sidious."),
        SWCharacter("Boba Fett", R.drawable.boba, "32 BBY", "Human", "None", "Kamino", "Bounty Hunters' Guild", "Bounty Hunter", "1.83 m", "EE-3 Carbine Rifle", "V, VI", "Jeremy Bulloch", "Famous Mandalorian bounty hunter."),
        SWCharacter("Rey", R.drawable.rey, "15 ABY", "Human", "Light Side", "Jakku", "Resistance", "Jedi Knight", "1.7 m", "Blue Lightsaber", "VII, VIII, IX", "Daisy Ridley", "Last hope of the Jedi.")
    )
}
