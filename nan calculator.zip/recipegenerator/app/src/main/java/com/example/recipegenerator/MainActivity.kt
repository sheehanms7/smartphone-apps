package com.example.recipegenerator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var recipeText: TextView
    private val ingredients = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        recipeText = findViewById(R.id.recipeText)

        val buttonMap = mapOf(
            R.id.btnChicken to "Chicken",
            R.id.btnRice to "Rice",
            R.id.btnSpices to "Spices",
            R.id.btnTomato to "Tomato",
            R.id.btnOnion to "Onion",
            R.id.btnOil to "Oil",
            R.id.btnGarlic to "Garlic",
            R.id.btnPotato to "Potatoes"
        )

        for ((id, name) in buttonMap) {
            findViewById<Button>(id).setOnClickListener {
                if (ingredients.size == 3 && !ingredients.contains(name)) {
                    Toast.makeText(this, "You can select up to 3 ingredients", Toast.LENGTH_SHORT).show()
                } else {
                    ingredients.add(name)
                    recipeText.text = "Ingredients: ${ingredients.joinToString(" + ")}"
                }
            }
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            ingredients.clear()
            recipeText.text = "Select ingredients..."
        }

        findViewById<Button>(R.id.btnGenerate).setOnClickListener {
            recipeText.text = generateRecipe()
        }

        findViewById<Button>(R.id.btnInfo).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("How to Use")
                .setMessage(
                    "• Tap up to three ingredient buttons to add to your list.\n" +
                            "• Tap “Generate Recipe” to see your dish.\n" +
                            "• Tap “Clear” to start over."
                )
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun generateRecipe(): String {
        if (ingredients.isEmpty()) return "No ingredients selected!"

        val sorted = ingredients.sorted()
        return when (sorted.size) {
            1 -> when (sorted[0]) {
                "Chicken"  -> "Grilled Chicken"
                "Rice"     -> "Steamed Rice"
                "Potatoes" -> "Baked Potato"
                "Tomato"   -> "Tomato Salad"
                "Onion"    -> "Caramelized Onions"
                "Garlic"   -> "Garlic Bread"
                "Oil"      -> "Seasoned Oil Dip"
                "Spices"   -> "Spice Mix"
                else       -> ""
            }
            2 -> {
                val key = sorted.joinToString("|")
                when (key) {
                    "Chicken|Rice"     -> "Chicken Fried Rice"
                    "Chicken|Potatoes" -> "Roasted Chicken & Potatoes"
                    "Tomato|Onion"     -> "Salsa"
                    "Tomato|Garlic"    -> "Tomato Garlic Sauce"
                    "Rice|Spices"      -> "Pilaf"
                    "Potatoes|Spices"  -> "Spiced Potato Wedges"
                    "Onion|Garlic"     -> "Sauteed Onions & Garlic"
                    "Rice|Oil"         -> "Pan-Fried Rice"
                    else               -> "${sorted.joinToString(" & ")} Stir-Fry"
                }
            }
            3 -> {
                val key = sorted.joinToString("|")
                when (key) {
                    "Chicken|Rice|Spices"   -> "Chicken Biryani"
                    "Tomato|Onion|Garlic"   -> "Tomato Curry"
                    "Potatoes|Oil|Spices"   -> "Spicy Fries"
                    "Rice|Onion|Oil"        -> "Fried Rice"
                    "Chicken|Garlic|Spices" -> "Garlic Chicken"
                    "Tomato|Onion|Spices"   -> "Shakshuka"
                    "Rice|Spices|Tomato"    -> "Tomato Rice"
                    "Chicken|Oil|Spices"    -> "Chicken Tikka"
                    "Potatoes|Onion|Spices" -> "Potato Bhaji"
                    "Garlic|Oil|Spices"     -> "Garlic Chili Oil"
                    "Oil|Onion|Tomato"      -> "Tomato-Onion Sauté"
                    else -> sorted.joinToString(" + ").let { "$it Stew" }
                }
            }
            else -> "Select up to 3 ingredients"
        }
    }

}
